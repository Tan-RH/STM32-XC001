#ifndef __DAC_H
#define __DAC_H	 
#include "sys.h"	    
								    
						    

void Dac2_Init(void);//�ػ�ģʽ��ʼ��		 	 
void Dac2_Set_Vol(u16 vol);
#endif

















